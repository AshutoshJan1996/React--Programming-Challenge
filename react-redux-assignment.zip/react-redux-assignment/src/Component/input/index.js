import React from 'react';
import './index.css';

const Input = (props) => {

    return(
        <div className='container'>
            <label className='label'>{props.label}</label>
            <input className='input'
                type="text" 
                onChange={props.changed}
                value={props.value} />
        </div>
    )

}

export default Input;