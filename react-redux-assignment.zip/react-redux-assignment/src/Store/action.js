export const ADD_PRODUCT = 'ADD_PRODUCT';
export const ADD_ADDRESS = 'ADD_ADDRESS';

export const addProdcut = (product, index) => {
    return {
        type:ADD_PRODUCT,
        product: product,
        index: index
    }
}

export const addAddress = (address) => {
    return {
        type:ADD_ADDRESS,
        address: address
    }
}