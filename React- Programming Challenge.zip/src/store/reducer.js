import * as actionTypes from './action';

const initialState = {
    result: [],
    loading: false,
    error: false
};

const reducer = ( state = initialState, action ) => {
    switch ( action.type ) {
        case actionTypes.SERACH_MUSIC_START:
            return {
                ...state,
                loading: true,
                error: false
            }
        case actionTypes.SERACH_MUSIC_SUCCESS:
            return {
                ...state,
                result: action.result,
                loading: false,
                error: false
            }
        case actionTypes.SERACH_MUSIC_FAIL:
            return {
                ...state,
                result: [],
                loading: false,
                error: true
            }    
        default: 
            return state;    
    }
};

export default reducer;
