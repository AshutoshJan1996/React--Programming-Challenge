import React from 'react';
import style from 'styled-components';

const Div = style.div`
margin-right: 3em;
margin-left: 3em;
margin-top: 1em;
border: 0.03em solid;
background: #eaeaea;
box-shadow: 0.2em 0.4em #888888;
`;

const List = (props) => {
    let grid = ( props.musiclist.map((item) => (
        <Div key = {item.trackId + Math.random()}>
            <p>{item.trackName}</p>
        </Div>
    )))
    return (
        <div>
            { grid }
        </div>
    )
};

export default List;