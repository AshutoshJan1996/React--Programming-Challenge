import * as actionTypes from './action';

const initialState = {
    productList: [
        {
            name: 'Apple',
            price: 10,
            quan: 1,
            isIncart: false
        },
        {
            name: 'Mango',
            price: 12,
            quan: 1,
            isIncart: false
        },
        {
            name: 'Orange',
            price: 9,
            quan: 1,
            isIncart: false
        }
    ],
    address: {}
};

const insertItem = (array, action) => {
    let newArray = array.slice()
    newArray[action.index] = action.product
    return newArray
}

const reducer = ( state = initialState, action ) => {
    switch ( action.type ) {
        case actionTypes.ADD_PRODUCT:
            return {
                ...state,
                productList: insertItem(state.productList, action)
            }
        case actionTypes.ADD_ADDRESS:
            return {
                ...state,
                address: action.address
            }   
        default: 
            return state;    
    }
};

export default reducer;