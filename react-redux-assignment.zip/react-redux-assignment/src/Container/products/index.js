import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import * as actionTypes from '../../Store/action';
import './index.css';

class Products extends Component {
    
    addToCart = (i) => {
          const products = this.props.prodcuts;
          const cuObj = this.props.prodcuts[i];
          cuObj.isIncart = true;
          products[i] = cuObj;
          this.props.onAdd(cuObj, i);
    }

    onClickNext = () => {
        this.props.history.push('shippingInfo');
    }

   returnListofProduct = () => {
       return(
            this.props.prodcuts.map((item, i) => (
                <div className="box" key={i}>
                    <h2>{item.name}</h2>
                    <p>per unit price is Rs.{item.price}</p>
                    <button disabled={item.isIncart} 
                     onClick={() => this.addToCart(i)} >Add to cart</button>
                    <p></p>
                </div>
           ))
       )
   }

  render(){
    return(
    <>
       <div className="header"> 
        <h1>Products </h1>
       </div>
       {this.returnListofProduct()}
       <div className="centered">
        <button onClick={this.onClickNext}>NEXT</button>
       </div>
    </>
    )
  }
}

const mapStateToProps = state => {
    return {
        prodcuts: state.productList
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onAdd: (product, index) => dispatch(actionTypes.addProdcut(product,index))
    }
};

export default withRouter( connect(mapStateToProps, mapDispatchToProps)(Products));