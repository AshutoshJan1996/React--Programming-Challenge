import React from 'react';
import style from 'styled-components';

const Div = style.div`
    margin-right: 5em;
    margin-left: 5em;
    margin-top: 1em;
    border: 0.03em solid;
    background: #eaeaea;
    box-shadow: 0.2em 0.4em #888888;
`;

const Error = () => (
    <Div>
        <p>something went wrong</p>
        <p>please try agian !!</p>
    </Div>
)

export default Error;