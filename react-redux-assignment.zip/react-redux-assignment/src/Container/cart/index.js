import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as actionTypes from '../../Store/action';
import './index.css'

class Cart extends Component {


  totalPrice = () => {
    let total = this.props.prodcuts.filter((item) => {
        return item.isIncart;
    }).reduce((total, item) => {
        return total + (item.quan * item.price);
      },0);
    return total
  }

  onQuanInput = (event, i) => {
    if(event.target.value < 1) {
        return
    }
    const products = this.props.prodcuts;
    const cuObj = this.props.prodcuts[i];
    cuObj.quan = event.target.value;
    products[i] = cuObj;
    this.props.onChangeQuant(cuObj, i);
  }

  onOrderCliked = () => {
      alert('You are order is Shiped Sucessfuly :-)');
  }

  returnProduct = () => {
    return(
      this.props.prodcuts.map((item, i) => {
        if(item.isIncart) {
          return(
            <div key={i}>
             <h3>{item.name}</h3>
             <p>Quantity: <input type='number' value={item.quan}
                onChange={(e) => this.onQuanInput(e,i)} />  X Price: {item.price}</p>
                <p>Sub Total: Rs.{item.quan * item.price}</p> 
             </div>
          )}
      }))    
  }

  returnShippinng = () => {
      let obj = this.props.address
    return(
      <>
        <h3>Name: {obj.username}</h3>
        <p>Adress: {obj.address1} {obj.address2}</p>
        <p>City: {obj.city}</p>
        <p>State: {obj.state}</p>
        <p>Country: {obj.country}</p>
        <div className='centered'>
          <button onClick={this.onOrderCliked}>ORDER</button>
        </div>
      </>
    )
  }

  render(){
    return(
      <div className='main'>
        <h1>Prodcuts in Cart</h1>
        {this.returnProduct()}
        <p>Total: Rs.{this.totalPrice()}</p>
        <h2>Shipping Info</h2>
        {this.returnShippinng()}
      </div>
    )
  }
}

const mapStateToProps = state => {
  return {
      prodcuts: state.productList,
      address: state.address
  };
};
const mapDispatchToProps = dispatch => {
  return {
      onChangeQuant: (product, index) => dispatch(actionTypes.addProdcut(product,index))
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(Cart);