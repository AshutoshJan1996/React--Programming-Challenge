export const SHOWING_RESULT = 'SHOWING_RESULT';
export const SERACH_MUSIC_START = 'SERACH_MUSIC_START';
export const SERACH_MUSIC_SUCCESS = 'SERACH_MUSIC_SUCCESS';
export const SERACH_MUSIC_FAIL = 'SERACH_MUSIC_FAIL';

export const serachMusic = (name) => {
    return {
        type: SHOWING_RESULT,
        name: name
    }
}

export const serachMusicStart = () => {
    return {
        type: SERACH_MUSIC_START
    }
}

export const serachMusicSuccess = (result) => {
    return {
        type: SERACH_MUSIC_SUCCESS,
        result: result
    }
}

export const serachMusicFail = () => {
    return {
        type: SERACH_MUSIC_FAIL
    }
}