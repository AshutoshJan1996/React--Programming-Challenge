import style from 'styled-components';

export const Div = style.div`
text-align: center;
`