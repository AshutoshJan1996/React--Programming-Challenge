import React, { Component } from 'react';
import { Route, Switch, withRouter } from 'react-router-dom';
import Products from './Container/products/index';
import ShippingInfo from './Container/shppingInfo/index';
import Cart from './Container/cart/index';

class App extends Component {

  render(){
    return(
      <Switch>
        <Route path="/" exact component={Products} />
        <Route path="/shippingInfo" component={ShippingInfo} />
        <Route path="/cart" component={Cart} />
      </Switch>
    )
  }
}

export default withRouter(App);
