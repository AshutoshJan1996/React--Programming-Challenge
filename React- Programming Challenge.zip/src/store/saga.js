import { takeLatest, put, delay } from 'redux-saga/effects';
import * as actionType from './action';
import { create } from 'apisauce';


const api = create({baseURL: 'https://itunes.apple.com'})

function* serachAsync( action ) {
    const artistName = action.name;
    yield put(actionType.serachMusicStart());
    yield delay(1000);
    try {
        const response = yield api.get('/search?term=' + artistName);
        const data = response.data.results;
        yield put(actionType.serachMusicSuccess( data ))
    } catch (error) {
        yield put(actionType.serachMusicFail())
    }
}

export function* watchSearchClick() {
    yield takeLatest(actionType.SHOWING_RESULT, serachAsync);
}