import React from 'react';
import './spinner.css'

const Spinner = () => (
    <div className='loader'>Loading...</div>
);

export default Spinner;