import React, { Component } from 'react';
import { connect } from 'react-redux';
import Button from '../../component/button/index';
import Input from '../../component/input/index';
import List from '../../component/list/index';
import Spinner from '../../component/spiner/index';
import Error from '../../component/error/index'; 
import * as actionTypes from '../../store/action';


class Home extends Component {

    state = {
        input: ''
    }

    inputhandler = (event) => {
        const updatedInput = event.target.value;
        this.setState({input: updatedInput});
    }

    onClickedSearch = () => {
        this.props.onSearch(this.state.input);
    }
    
    render () {
        let list = <List musiclist = {this.props.resl} />
        if (this.props.loading === true) {
            list = <Spinner />
        }
        if (this.props.err === true) {
            list = <Error />
        }
        return(
            <>
              <h2>iTune Search By Artist</h2>
              <Input change = {(event) => this.inputhandler(event)} />
              <Button clicked = {this.onClickedSearch}>Search</Button>
              { list }
            </>
        )
    }
}

const mapStateToProps = state => {
    return {
        resl: state.result,
        loading: state.loading,
        err: state.error
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onSearch: (artist) => dispatch(actionTypes.serachMusic(artist))
    }
};


export default connect(mapStateToProps, mapDispatchToProps)(Home);