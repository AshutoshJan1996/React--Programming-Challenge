import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import Input from '../../Component/input/index';
import { connect } from 'react-redux';
import * as actionTypes from '../../Store/action';
import './index.css';

class ShippingInfo extends Component {

  state = {
    input:{
        username: '',
        address1: '',
        address2: '',
        country: '',
        city: '',
        state: ''
    }
  }

  handelChanged = (event, type) => {
    const upadted = this.state.input;
    upadted[type] = event.target.value;
    this.setState({input : upadted})
  }

  onClickNext = () => {
      this.props.onAddAddress(this.state.input)
      this.props.history.push('cart');
  }

  render(){
    return(
      <>
      <div className='main'>
      <h1>Shipping Address</h1>
      <Input label='User Name'
               value={this.state.input.username}
               changed={(event) => this.handelChanged(event, 'username')} />
      <Input label='Address Line1'
               value={this.state.input.address1}
               changed={(event) => this.handelChanged(event, 'address1')} />
      <Input label='Address Line2'
               value={this.state.input.address2}
               changed={(event) => this.handelChanged(event, 'address2')} />
      <Input label='City'
               value={this.state.input.city}
               changed={(event) => this.handelChanged(event, 'city')} />
      <Input label='State'
               value={this.state.input.state}
               changed={(event) => this.handelChanged(event, 'state')} />
      <Input label='Country'
               value={this.state.input.country}
               changed={(event) => this.handelChanged(event, 'country')} />                                                    
      </div>
      <div className='centered'>
        <button onClick={this.onClickNext}>NEXT</button>
      </div>
      </>
    )
  }
}

const mapDispatchToProps = dispatch => {
  return {
      onAddAddress: (obj) => dispatch(actionTypes.addAddress(obj))
  }
};

export default withRouter( connect('', mapDispatchToProps)(ShippingInfo));