import React from 'react';
import style from 'styled-components';

const CustomInput = style.input`
    background: #eaeaea;
    border: none;
    border-radius: 3px;
    padding: 0.5em;
    margin: 0.5em;
`;

const Input = (props) => {
    return (
        <CustomInput 
        type='text'
        onChange = {props.change} />
    )
};

export default Input;