import React, { Component }from 'react';
import { Div } from './AppStyleCompo';
import Home from './container/home/index';


class App extends Component {

  render() {
  return (
    <Div>
       <Home />
    </Div>
  )}
}

export default App;
